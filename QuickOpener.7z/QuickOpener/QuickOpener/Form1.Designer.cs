﻿using System.Windows.Forms;
namespace QuickOpener
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if( disposing && ( components != null ) )
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent( )
        {
            this.tbSearch = new System.Windows.Forms.TextBox();
            this.openApp = new System.Windows.Forms.Button();
            this.lbAllItemList = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbAppName = new System.Windows.Forms.TextBox();
            this.tbAlias = new System.Windows.Forms.TextBox();
            this.tbFullPath = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbBatchopenItemList = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnBatchOpen = new System.Windows.Forms.Button();
            this.btnAddToBatchList = new System.Windows.Forms.Button();
            this.btnDeleteFromBatchList = new System.Windows.Forms.Button();
            this.btnDeleteFromFavoriteList = new System.Windows.Forms.Button();
            this.btnAddToFavoritesList = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lbAliasWarning = new System.Windows.Forms.Label();
            this.lbNameWarning = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbFullPathWarning = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // tbSearch
            // 
            this.tbSearch.Location = new System.Drawing.Point(12, 12);
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(237, 20);
            this.tbSearch.TabIndex = 0;
            this.tbSearch.TextChanged += new System.EventHandler(this.tbSearch_TextChanged);
            // 
            // openApp
            // 
            this.openApp.Location = new System.Drawing.Point(255, 10);
            this.openApp.Name = "openApp";
            this.openApp.Size = new System.Drawing.Size(75, 23);
            this.openApp.TabIndex = 1;
            this.openApp.Text = "Open";
            this.openApp.UseVisualStyleBackColor = true;
            this.openApp.Click += new System.EventHandler(this.openApp_Click);
            // 
            // lbAllItemList
            // 
            this.lbAllItemList.FormattingEnabled = true;
            this.lbAllItemList.Location = new System.Drawing.Point(12, 222);
            this.lbAllItemList.Name = "lbAllItemList";
            this.lbAllItemList.Size = new System.Drawing.Size(160, 134);
            this.lbAllItemList.TabIndex = 2;
            this.lbAllItemList.SelectedIndexChanged += new System.EventHandler(this.lbAllItemList_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "App Name";
            // 
            // tbAppName
            // 
            this.tbAppName.Location = new System.Drawing.Point(71, 84);
            this.tbAppName.Name = "tbAppName";
            this.tbAppName.Size = new System.Drawing.Size(181, 20);
            this.tbAppName.TabIndex = 4;
            this.tbAppName.TextChanged += new System.EventHandler(this.tbAppName_TextChanged);
            // 
            // tbAlias
            // 
            this.tbAlias.Location = new System.Drawing.Point(71, 110);
            this.tbAlias.Name = "tbAlias";
            this.tbAlias.Size = new System.Drawing.Size(181, 20);
            this.tbAlias.TabIndex = 5;
            // 
            // tbFullPath
            // 
            this.tbFullPath.Location = new System.Drawing.Point(71, 136);
            this.tbFullPath.Name = "tbFullPath";
            this.tbFullPath.Size = new System.Drawing.Size(331, 20);
            this.tbFullPath.TabIndex = 6;
            this.tbFullPath.TextChanged += new System.EventHandler(this.tbFullPath_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Alias";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Full Path";
            // 
            // lbBatchopenItemList
            // 
            this.lbBatchopenItemList.FormattingEnabled = true;
            this.lbBatchopenItemList.Location = new System.Drawing.Point(228, 219);
            this.lbBatchopenItemList.Name = "lbBatchopenItemList";
            this.lbBatchopenItemList.Size = new System.Drawing.Size(160, 134);
            this.lbBatchopenItemList.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(265, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Drag app icon into Quick Opener or Edit following rows";
            // 
            // btnBatchOpen
            // 
            this.btnBatchOpen.Location = new System.Drawing.Point(336, 10);
            this.btnBatchOpen.Name = "btnBatchOpen";
            this.btnBatchOpen.Size = new System.Drawing.Size(75, 23);
            this.btnBatchOpen.TabIndex = 11;
            this.btnBatchOpen.Text = "Batch Open";
            this.btnBatchOpen.UseVisualStyleBackColor = true;
            this.btnBatchOpen.Click += new System.EventHandler(this.btnBatchOpen_Click);
            // 
            // btnAddToBatchList
            // 
            this.btnAddToBatchList.Location = new System.Drawing.Point(176, 268);
            this.btnAddToBatchList.Name = "btnAddToBatchList";
            this.btnAddToBatchList.Size = new System.Drawing.Size(43, 23);
            this.btnAddToBatchList.TabIndex = 12;
            this.btnAddToBatchList.Text = ">>";
            this.btnAddToBatchList.UseVisualStyleBackColor = true;
            this.btnAddToBatchList.Click += new System.EventHandler(this.btnAddToBatchList_Click);
            // 
            // btnDeleteFromBatchList
            // 
            this.btnDeleteFromBatchList.Location = new System.Drawing.Point(239, 362);
            this.btnDeleteFromBatchList.Name = "btnDeleteFromBatchList";
            this.btnDeleteFromBatchList.Size = new System.Drawing.Size(130, 23);
            this.btnDeleteFromBatchList.TabIndex = 13;
            this.btnDeleteFromBatchList.Text = "Delete from batch list";
            this.btnDeleteFromBatchList.UseVisualStyleBackColor = true;
            this.btnDeleteFromBatchList.Click += new System.EventHandler(this.btnDeleteFromBatchList_Click);
            // 
            // btnDeleteFromFavoriteList
            // 
            this.btnDeleteFromFavoriteList.Location = new System.Drawing.Point(15, 362);
            this.btnDeleteFromFavoriteList.Name = "btnDeleteFromFavoriteList";
            this.btnDeleteFromFavoriteList.Size = new System.Drawing.Size(141, 23);
            this.btnDeleteFromFavoriteList.TabIndex = 14;
            this.btnDeleteFromFavoriteList.Text = "Delete from favorites list";
            this.btnDeleteFromFavoriteList.UseVisualStyleBackColor = true;
            this.btnDeleteFromFavoriteList.Click += new System.EventHandler(this.btnDeleteFromFavoriteList_Click);
            // 
            // btnAddToFavoritesList
            // 
            this.btnAddToFavoritesList.Location = new System.Drawing.Point(71, 162);
            this.btnAddToFavoritesList.Name = "btnAddToFavoritesList";
            this.btnAddToFavoritesList.Size = new System.Drawing.Size(67, 23);
            this.btnAddToFavoritesList.TabIndex = 15;
            this.btnAddToFavoritesList.Text = "Save";
            this.btnAddToFavoritesList.UseVisualStyleBackColor = true;
            this.btnAddToFavoritesList.Click += new System.EventHandler(this.btnAddToFavoritesList_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(190, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 16;
            // 
            // lbAliasWarning
            // 
            this.lbAliasWarning.AutoSize = true;
            this.lbAliasWarning.Location = new System.Drawing.Point(258, 113);
            this.lbAliasWarning.Name = "lbAliasWarning";
            this.lbAliasWarning.Size = new System.Drawing.Size(0, 13);
            this.lbAliasWarning.TabIndex = 17;
            // 
            // lbNameWarning
            // 
            this.lbNameWarning.AutoSize = true;
            this.lbNameWarning.Location = new System.Drawing.Point(259, 90);
            this.lbNameWarning.Name = "lbNameWarning";
            this.lbNameWarning.Size = new System.Drawing.Size(0, 13);
            this.lbNameWarning.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(265, 203);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Batch open items list";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 203);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "All items list";
            // 
            // lbFullPathWarning
            // 
            this.lbFullPathWarning.AutoSize = true;
            this.lbFullPathWarning.Location = new System.Drawing.Point(144, 167);
            this.lbFullPathWarning.Name = "lbFullPathWarning";
            this.lbFullPathWarning.Size = new System.Drawing.Size(0, 13);
            this.lbFullPathWarning.TabIndex = 21;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(228, 183);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(102, 17);
            this.listBox1.TabIndex = 22;
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 422);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lbFullPathWarning);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbNameWarning);
            this.Controls.Add(this.lbAliasWarning);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnAddToFavoritesList);
            this.Controls.Add(this.btnDeleteFromFavoriteList);
            this.Controls.Add(this.btnDeleteFromBatchList);
            this.Controls.Add(this.btnAddToBatchList);
            this.Controls.Add(this.btnBatchOpen);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbBatchopenItemList);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbFullPath);
            this.Controls.Add(this.tbAlias);
            this.Controls.Add(this.tbAppName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbAllItemList);
            this.Controls.Add(this.openApp);
            this.Controls.Add(this.tbSearch);
            this.Name = "Form1";
            this.Text = "Quick Opener";
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.Form1_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.Form1_DragEnter);
            this.ResumeLayout(false);
            this.PerformLayout();

        }        

        #endregion

        private System.Windows.Forms.TextBox tbSearch;
        private System.Windows.Forms.Button openApp;
        private ListBox lbAllItemList;
        private Label label1;
        private TextBox tbAppName;
        private TextBox tbAlias;
        private TextBox tbFullPath;
        private Label label2;
        private Label label3;
        private ListBox lbBatchopenItemList;
        private Label label4;
        private Button btnBatchOpen;
        private Button btnAddToBatchList;
        private Button btnDeleteFromBatchList;
        private Button btnDeleteFromFavoriteList;
        private Button btnAddToFavoritesList;
        private Label label5;
        private Label lbAliasWarning;
        private Label lbNameWarning;
        private Label label6;
        private Label label7;
        private Label lbFullPathWarning;
        private ListBox listBox1;
    }
}

