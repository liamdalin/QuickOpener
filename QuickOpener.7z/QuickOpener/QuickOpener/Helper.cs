﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickOpener
{
    public enum BatchOpenType
    {
        NotBatchOpen,
        BatchOpenByName,
        BatchOpenByAlias,
        BatchOpenByAll
    }

    public class FavoriteItem
    {
        private string itemName;
        private string alias;
        private string fullPathWay;
        private BatchOpenType batchOpenType;

        public string ItemName
        {
            get
            {
                return this.itemName;
            }
            set
            {
                this.itemName = value;
            }
        }
        public string Alias
        {
            get
            {
                return this.alias;
            }
            set
            {
                this.alias = value;
            }
        }

        public string FullPathWay
        {
            get
            {
                return this.fullPathWay;
            }
            set
            {
                this.fullPathWay = value;
            }
        }

        public BatchOpenType BatchOpenType
        {
            get
            {
                return this.batchOpenType;
            }
            set
            {
                this.batchOpenType = value;
            }
        }

        public FavoriteItem( )
        {
            BatchOpenType = BatchOpenType.NotBatchOpen;
        }
    }

    public class XmlTemplet : ICollection
    {
        private ArrayList empArray = new ArrayList( );

        public int Count
        {
            get
            {
                return empArray.Count;
            }
        }
        public object SyncRoot
        {
            get
            {
                return this;
            }
        }
        public bool IsSynchronized
        {
            get
            {
                return false;
            }
        }

        public XmlTemplet( )
        {
        }

        public XmlTemplet( Dictionary<string, FavoriteItem> allItems )
        {
            foreach( var keyValuePair in allItems )
            {
                if( !ContainSameItem( keyValuePair.Value ) )
                {
                    Add( keyValuePair.Value );
                }                
            }
        }

        public void Add( FavoriteItem item )
        {
            empArray.Add( item );
        }

        public FavoriteItem this[ int index ]
        {
            get
            {
                return ( FavoriteItem )empArray[ index ];
            }
        }

        public void CopyTo( Array a, int index )
        {
            empArray.CopyTo( a, index );
        }
        
        public IEnumerator GetEnumerator( )
        {
            return empArray.GetEnumerator( );
        }

        private bool ContainSameItem(FavoriteItem newItem )
        {
            foreach( var item in empArray )
            {
                FavoriteItem favoriteItem = ( FavoriteItem )item;
                if( ( favoriteItem.ItemName == newItem.ItemName ) && ( favoriteItem.FullPathWay == newItem.FullPathWay ) )
                {
                    return true;
                }
            }

            return false;
        }

    }

    public class Helper
    {        
        private System.Xml.Serialization.XmlSerializer reader;
        private System.Xml.Serialization.XmlSerializer writer;            
        private string xmlPath = System.Environment.CurrentDirectory + @"\savedItems.xml";

        public Helper( )
        {
            reader = new System.Xml.Serialization.XmlSerializer( typeof( XmlTemplet ) );
            writer = new System.Xml.Serialization.XmlSerializer( typeof( XmlTemplet ) );
        }

        public void saveToXml( Dictionary<string, FavoriteItem> allItems )
        {
            try
            {
                FileInfo fi = new FileInfo( xmlPath );
                if( !fi.Exists )
                {
                    FileStream fs = fi.Create( );
                    fs.Close();
                }

                using( System.IO.StreamWriter file = new System.IO.StreamWriter( fi.Open( FileMode.Truncate ) ) )
                {
                    //save data to xml file
                    XmlTemplet xmlTemplet = new XmlTemplet( allItems );
                    writer.Serialize( file, xmlTemplet );
                    file.Close( );
                }                
            }
            catch(Exception ex)
            {
            }       
        }

        public Dictionary<string, FavoriteItem> retrieveFromXml( )
        {
            Dictionary<string, FavoriteItem> allItems = new Dictionary<string, FavoriteItem>( );
            try
            {
                using( System.IO.StreamReader file = new System.IO.StreamReader( xmlPath ) )
                {
                    XmlTemplet xmlTemplet = ( XmlTemplet )reader.Deserialize( file );

                    IEnumerator enumerator = xmlTemplet.GetEnumerator( );

                    while( enumerator.MoveNext( ) )
                    {
                        var item = ( FavoriteItem )enumerator.Current;

                        if( !string.IsNullOrEmpty( item.ItemName ) )
                        {
                            allItems.Add( item.ItemName, item );
                        }

                        if( !string.IsNullOrEmpty( item.Alias ) )
                        {
                            allItems.Add( item.Alias, item );
                        }
                    }

                    return allItems;
                }
                
            }
            catch( Exception ex )
            {
            }

            return allItems;
        }
    }
}
