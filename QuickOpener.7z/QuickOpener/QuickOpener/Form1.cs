﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuickOpener
{       
    public partial class Form1 : Form
    {
        Dictionary<string, FavoriteItem> allItems;
        Helper helper;

        public Form1( )
        {
            InitializeComponent( );
            helper = new Helper( );
            retrieveItems( );
            this.tbSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.tbSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tbSearch.AutoCompleteCustomSource.AddRange( allItems.Keys.ToArray( ) );
            this.AcceptButton = openApp;
        }

        private void Form1_DragEnter( object sender, System.Windows.Forms.DragEventArgs e )
        {
            if( e.Data.GetDataPresent( DataFormats.FileDrop ) )
                e.Effect = DragDropEffects.Link;
            else
                e.Effect = DragDropEffects.None;
        }

        private void Form1_DragDrop( object sender, System.Windows.Forms.DragEventArgs e )
        {
            //show details of dragged item ；
            showDragItem(( ( System.Array )e.Data.GetData( DataFormats.FileDrop ) ).GetValue( 0 ).ToString( ));
        }

        private void openApp_Click( object sender, EventArgs e )
        {
            var searchText = tbSearch.Text.Trim( );
            if( string.IsNullOrEmpty( searchText ) )
            {
                return;
            }

            var item = findItemBySearchText( searchText );
            var cmdText = item != null ? item.FullPathWay : searchText;
            if( !string.IsNullOrEmpty( cmdText ) )
            {
                openItem( cmdText );
            }            
        }        

        //Item name is Key. Alias is opional, but is still be another key, so one item has 1~2 keys. 
        //One Item only has one alias. Different items could point to the same full path.
        private void btnAddToFavoritesList_Click( object sender, EventArgs e )
        {
            this.lbNameWarning.Text = string.Empty;
            this.lbFullPathWarning.Text = string.Empty;
            this.lbAliasWarning.Text = string.Empty;

            FavoriteItem newItem = new FavoriteItem( );
            newItem.Alias = tbAlias.Text.Trim();
            newItem.ItemName = tbAppName.Text.Trim( );
            newItem.FullPathWay = tbFullPath.Text.Trim( );

            if (string.IsNullOrEmpty(newItem.ItemName))
            {
                this.lbNameWarning.Text = "Item Name must not be empty";
                return;
            }
            else if( string.IsNullOrEmpty( newItem.FullPathWay ) )
            {
                this.lbFullPathWarning.Text = "Full Path must not be empty";                
                return;
            }
            else
            {
                if( allItems.ContainsKey( newItem.ItemName ) && ( allItems[ newItem.ItemName ].FullPathWay != newItem.FullPathWay ) )
                {
                    this.lbNameWarning.Text = "please input an unique name";
                    return;
                }
            }

            if( !string.IsNullOrEmpty( newItem.Alias ) && allItems.ContainsKey( newItem.Alias ) )
            {
                if( !allItems.ContainsKey( newItem.ItemName ) || newItem.Alias != allItems[ newItem.ItemName ].Alias )
                {
                    this.lbAliasWarning.Text = "please input an unique alias";
                    return;
                }
            }

            if( allItems.ContainsKey( newItem.ItemName ) )
            {
                if( ( allItems[ newItem.ItemName ].Alias == newItem.Alias ) && ( allItems[ newItem.ItemName ].ItemName == newItem.ItemName ) && ( allItems[ newItem.ItemName ].FullPathWay == newItem.FullPathWay ) )
                {
                    return;
                }
            }

            saveNewItem( newItem );
            refreshTool( );                       
        }
        
        private void btnAddToBatchList_Click( object sender, EventArgs e )
        {
            if( lbAllItemList.SelectedItem != null && allItems.ContainsKey( lbAllItemList.SelectedItem.ToString( ) ) )
            {
                addItemToBatchList( lbAllItemList.SelectedItem.ToString( ) );
            }
        }

        private void btnBatchOpen_Click( object sender, EventArgs e )
        {
            foreach( var keyValuePair in allItems )
            {
                if( keyValuePair.Value.BatchOpenType != BatchOpenType.NotBatchOpen )
                {
                    openItem( keyValuePair.Value.FullPathWay );
                }
            }
        }

        //delete item by itemName, item will be deleted and alias key also is deleted, related batch item also is deleted
        //delete item by alias, alias key will be deleted, and related batch item also is deleted
        private void btnDeleteFromFavoriteList_Click( object sender, EventArgs e )
        {
            if( lbAllItemList.SelectedItem == null )
            {
                return;
            }

            var selectedText = lbAllItemList.SelectedItem.ToString( );
            if( allItems[ selectedText ].ItemName == selectedText )
            {
                if( !string.IsNullOrEmpty( allItems[ selectedText ].Alias ) )
                {
                    allItems.Remove( allItems[ selectedText ].Alias );
                }
                allItems.Remove( selectedText );
            }
            else if( allItems[ selectedText ].Alias == selectedText )
            {
                var itemName = allItems[ selectedText ].ItemName;
                allItems[ itemName ].Alias = string.Empty;
                allItems.Remove( selectedText );
            }

            refreshAllItemListBox( );
            refreshBatchOpenListBox( );
            saveItemsToXml( );
        }

        private void btnDeleteFromBatchList_Click( object sender, EventArgs e )
        {
            if( lbBatchopenItemList.SelectedItem == null )
            {
                return;
            }

            var selectedText = lbBatchopenItemList.SelectedItem.ToString( );
            if( allItems[ selectedText ].ItemName == selectedText )
            {
                if( allItems[ selectedText ].BatchOpenType == BatchOpenType.BatchOpenByAll )
                {
                    allItems[ selectedText ].BatchOpenType = BatchOpenType.BatchOpenByAlias;
                }
                else
                {
                    allItems[ selectedText ].BatchOpenType = BatchOpenType.NotBatchOpen;
                }
            }

            if( allItems[ selectedText ].Alias == selectedText )
            {
                if( allItems[ selectedText ].BatchOpenType == BatchOpenType.BatchOpenByAll )
                {
                    allItems[ selectedText ].BatchOpenType = BatchOpenType.BatchOpenByName;
                }
                else
                {
                    allItems[ selectedText ].BatchOpenType = BatchOpenType.NotBatchOpen;
                }
            }

            refreshBatchOpenListBox( );
            saveItemsToXml( );
        }

        private void tbAppName_TextChanged( object sender, EventArgs e )
        {
            if( !string.IsNullOrEmpty( tbAppName.Text ) )
            {
                this.lbNameWarning.Text = string.Empty;
            }
        }

        private void tbFullPath_TextChanged( object sender, EventArgs e )
        {
            if( !string.IsNullOrEmpty( tbFullPath.Text ) )
            {
                this.lbFullPathWarning.Text = string.Empty;
            }
        }

        private void lbAllItemList_SelectedIndexChanged( object sender, EventArgs e )
        {
            if( lbAllItemList.SelectedItem == null )
            {
                return;
            }

            var selectedItem = lbAllItemList.SelectedItem.ToString( );
            if( allItems.ContainsKey( selectedItem ) )
            {
                tbAlias.Text = allItems[ selectedItem ].Alias;
                tbFullPath.Text = allItems[ selectedItem ].FullPathWay;
                tbAppName.Text = allItems[ selectedItem ].ItemName;
                tbSearch.Text = tbAppName.Text;
            }
        }

        private void tbSearch_TextChanged( object sender, EventArgs e )
        {
            var searchText = tbSearch.Text.Trim( );
            if( allItems.ContainsKey( searchText ) )
            {
                tbAlias.Text = allItems[ searchText ].Alias;
                tbFullPath.Text = allItems[ searchText ].FullPathWay;
                tbAppName.Text = allItems[ searchText ].ItemName;
            }
        }

        private void showDragItem( string fullPathway )
        {
            var lastVirguleIndex = fullPathway.LastIndexOf( "\\" );
            var itemName = fullPathway.Substring( lastVirguleIndex + 1 );

            tbAlias.Text = string.Empty;
            tbAppName.Text = itemName;
            tbFullPath.Text = fullPathway;
            if( allItems.ContainsKey( itemName ) )
            {
                tbAlias.Text = allItems[ itemName ].Alias;
            }
        }

        private void saveNewItem( FavoriteItem newItem )
        {
            if( !allItems.ContainsKey( newItem.ItemName ) )
            {
                allItems.Add( newItem.ItemName, newItem );
                if( !string.IsNullOrEmpty( newItem.Alias ) )
                {
                    allItems.Add( newItem.Alias, newItem );
                }                
                return;
            }

            //find existing item
            var alias = allItems[ newItem.ItemName ].Alias;
            if( !string.IsNullOrEmpty( alias ) && allItems.ContainsKey( alias ) )
            {
                allItems.Remove( alias );
            }

            //in case user change full path
            allItems.Remove( newItem.ItemName );
            allItems.Add( newItem.ItemName, newItem );
            allItems.Add( newItem.Alias, newItem );
        }        

        private void refreshTool( )
        {
            refreshAllItemListBox( );
            refreshBatchOpenListBox( );
            refreshSearchSource( );
            saveItemsToXml( );
        }

        private void refreshAllItemListBox( )
        {
            var allKeys = allItems.Keys.ToArray();
            Array.Sort( allKeys );
            this.lbAllItemList.Items.Clear( );
            this.lbAllItemList.Items.AddRange( allKeys );         
        }

        private void refreshBatchOpenListBox( )
        {
            List<string> batchOpenNameList = new List<string>();
            this.lbBatchopenItemList.Items.Clear( );
            foreach( var keyValuePair in allItems )
            {
                switch( keyValuePair.Value.BatchOpenType )
                {
                    case BatchOpenType.BatchOpenByAlias:
                    {
                        if( !batchOpenNameList.Contains( keyValuePair.Value.Alias ) )
                        {
                            batchOpenNameList.Add( keyValuePair.Value.Alias );
                        }
                        
                        break;
                    }
                    case BatchOpenType.BatchOpenByName:
                    {
                        if( !batchOpenNameList.Contains( keyValuePair.Value.ItemName ) )
                        {
                            batchOpenNameList.Add( keyValuePair.Value.ItemName );
                        }
                        
                        break;
                    }
                    case BatchOpenType.BatchOpenByAll:
                    {
                        if( !batchOpenNameList.Contains( keyValuePair.Value.ItemName ) )
                        {
                            batchOpenNameList.Add( keyValuePair.Value.ItemName );
                        }
                        if( !batchOpenNameList.Contains( keyValuePair.Value.Alias ) )
                        {
                            batchOpenNameList.Add( keyValuePair.Value.Alias );
                        }
                                                
                        break;
                    }
                    default:
                        break;
                }                
            }

            Array.Sort( batchOpenNameList.ToArray( ) );
            lbBatchopenItemList.Items.AddRange( batchOpenNameList.ToArray( ) );            
        }

        private void refreshSearchSource( )
        {
            this.tbSearch.AutoCompleteCustomSource = new AutoCompleteStringCollection( );
            this.tbSearch.AutoCompleteCustomSource.AddRange( allItems.Keys.ToArray( ) );
        }

        private void saveItemsToXml( )
        {
            helper.saveToXml( allItems );
        }

        private void retrieveItems( )
        {
            allItems = helper.retrieveFromXml( );
            refreshAllItemListBox( );
            refreshBatchOpenListBox( );
        }        

        private FavoriteItem findItemBySearchText( string searchText )
        {
            searchText = searchText.Trim( ).ToLower( );
            foreach( var key in allItems.Keys )
            {
                if( string.Equals( key.ToLower( ), searchText ) )
                {
                    return allItems[key];
                }
            }

            return null;
        }

        private void openItem( string path )
        {
            try
            {
                System.Diagnostics.Process.Start( path );
            }
            catch (Exception ex)
            {
                MessageBox.Show( "Can not open this app!" );
            }            
        }
        
        private void addItemToBatchList( string keyText )
        {
            if( lbBatchopenItemList.Items.Contains( keyText ) )
            {
                return;
            }

            var item = allItems[ keyText ];
            if( item.Alias == keyText )
            {
                if( item.BatchOpenType == BatchOpenType.NotBatchOpen )
                {
                    item.BatchOpenType = BatchOpenType.BatchOpenByAlias;
                }
                else if( item.BatchOpenType == BatchOpenType.BatchOpenByName )
                {
                    item.BatchOpenType = BatchOpenType.BatchOpenByAll;
                }
            }
            else if( item.ItemName == keyText )
            {
                if( item.BatchOpenType == BatchOpenType.NotBatchOpen )
                {
                    item.BatchOpenType = BatchOpenType.BatchOpenByName;
                }
                else if( item.BatchOpenType == BatchOpenType.BatchOpenByAlias )
                {
                    item.BatchOpenType = BatchOpenType.BatchOpenByAll;
                }
            }

            refreshBatchOpenListBox( );
            saveItemsToXml( );
        }        
    }    
}
